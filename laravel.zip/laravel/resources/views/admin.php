<!DOCTYPE HTML>

<head>

	<title>Ninjas bildeapp</title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

	<script src="<?php echo asset('js/jquery-1.11.1.min.js'); ?>"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo asset('css/main.css'); ?>">
	
</head>

<body>

	<div class="container-fluid">
	
		<div class="row">
		
			<div class="col-md-12">
			
				<h1 style="text-align:center;">Ninja´s bildeapp - Admin <a href='/' class='btn btn-info btn-xs'>Back to home page</a></h1> 
				
			</div>
			
		</div>
		
		<div class="row">
		
			<div class="col-md-12">
			
				<?php
					if(isset($_GET["image_id"])){
						
						if($_GET["action"] == "approve"){
							DB::table('images')
				            ->where('image_id', $_GET["image_id"])
				            ->update(['approved' => 1]);
				            echo "<div class='alert alert-success' role='alert'>Image id ".$_GET["image_id"]." was successfully approved</div>";
						}
						
			            if($_GET["action"] == "delete"){
							DB::table('images')
				            ->where('image_id', $_GET["image_id"])
				            ->update(['deleted' => 1]);
				            echo "<div class='alert alert-danger' role='alert'>Image id ".$_GET["image_id"]." was successfully deleted</div>";
						}
						
					}
				?>
				
			</div>
			
		</div>
		
		<div class="row">
		
			<div class="col-md-6">
			
				<h3>NOT approved images</h3>
				
			</div>	
			
		</div>	
		
		<div class="row">
		
			<?php
				$images = DB::table('images')->where('approved', 0)->where('deleted', 0)->join('users', function ($join) {
            	$join->on('images.user_id', '=', 'users.user_id');})->get();
			
				if(empty($images)){
			
					echo "<div class='col-md-12'>";
						echo "<div class='alert alert-warning' role='alert'>No new images to approve...</div>";
					echo "</div>";
				
				}else{
			
					foreach ($images as $image) {

				    	echo "<div class='col-lg-3 col-md-4 col-xs-6 thumb'>";
				    		echo "<div class='imagebox'>";
				    			echo "<img src='".asset('uploads/'.$image->path)."' alt='Default' height='200' width='200'>";
				    			echo "<h5>From: ".$image->name."</h5>";
							
								echo "<p style='margin-top: 10px;'>";
									echo "<a href='/admin?image_id=".$image->image_id."&action=approve' class='btn btn-success btn-md'><span class='glyphicon glyphicon-ok'></span> Approve</a>";
									echo "<a href='/admin?image_id=".$image->image_id."&action=delete' class='btn btn-danger btn-md'><span class='glyphicon glyphicon-remove'></span> Delete</a>";
								echo "</p>";
							echo "</div>";		
						echo "</div>";

					}
				
				}	
			
			?>
		
		</div>

	</div>
			
</body>
	
</html>