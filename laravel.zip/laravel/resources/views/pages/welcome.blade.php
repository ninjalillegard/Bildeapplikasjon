@extends('app')

@section('content')

{!! $feedback !!}

<div class="container-fluid">

	<div class="row">
		<div class="col-md-12">
			<h1 style="text-align:center;">Ninja´s bildeapp</h1>
		</div>
	</div>
	
	<div class="clearfix"></div>

	@if ($user_id == 0)
		
		<div class="row">
			<div class="col-md-4 col-md-offset-2">
			
				<h3>Registrering</h3>
			
				<form action="" method="get" name="registrering" value="registrering" class="box">
				
					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-user"></div></span>
							<input type="text" id="input_name" name="input_name" value="" placeholder="Name" class="form-control" />
						</div>
					</p>
					
					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-camera"></div></span>
							<input type="text" id="input_instagram" name="input_instagram" value="" placeholder="Instagram username" class="form-control" />
						</div>
					</p>	
					
					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-envelope"></div></span>
							<input type="text" id="input_email" name="input_email" value="" placeholder="Email" class="form-control" />
						</div>
					</p>	
					
					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-pencil"></div></span>
							<input type="password" id="input_password" name="input_password" placeholder="Password" value="" class="form-control" />
						</div>
					<p>	

					<p>
						<div class="btn-group">
							<input  class="btn btn-default btn-sm dropdown-toggle" type="submit" id="registrer" name="registrer" value="Registrer" />
						</div>
					</p>
					
				</form>		
				
			</div>

			<div class="col-md-4">
				
				<h3>Log in</h3>
					
				<form action="" method="get" name="registrering" value="registrering" class="box">
				
					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-envelope"></div></span>
							<input type="text" id="input_email" name="input_email" value="" placeholder="Email" class="form-control" />
						</div>
					</p>	

					<p>
						<div class="input-group">
							<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-pencil"></div></span>
							<input type="password" id="input_password" name="input_password" placeholder="Password" value="" class="form-control" />
						</div>
					</p>	
					
					<p>
						<div class="btn-group">
							<input  class="btn btn-default btn-sm dropdown-toggle" type="submit" id="login" name="login" value="Login" />
						</div>
					</p>
					
				</form>
				
			</div>
			
		</div>
		
	@else

		<h3>Images uploaded by: {{ $user_name }} <a href='/?logout=true' class='btn btn-info btn-xs'>Logout</a></h3>
	
		{!! $userimages !!}

	@endif	
	
</div>	

<hr />


@if ($user_id > 0)

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4">
			
				<h3>Fileupload</h3>
				
				<form action="{{ URL::to('upload') }}" method="post" enctype="multipart/form-data" class="box">

				  <input type="file" name="file" id="file" placeholder="Select image to upload" style="float:left;">
				  <input type="submit" class="btn btn-default" value="Upload" name="submit" style="float:left;">
				  
				  <input type="hidden" value="{{ $user_id }}" name="userid" id="userid">
				  <input type="hidden" value="{{ csrf_token() }}" name="_token">
				  
				  <div class="clearfix"></div>

				</form>
				
			</div>
			
			<div class="col-md-8">
			
				<h3>Instagram - <small>Choose image to upload</small></h3>
				
				<div class="container-fluid">
				
					<div class="row">
							
						{!! $instagramimages !!}	
						
						<div class="clearfix"></div>
						
					</div>	
					
				</div>
				
			</div>
			
		</div>
		
	</div>	
	
	<hr />

@endif	

	<div class="container-fluid">
	
		<div class="row">
		
			<h2 style="text-align:center;">All images</h2>

			{!! $allimages !!}
			
		</div>
		
	</div>


@stop