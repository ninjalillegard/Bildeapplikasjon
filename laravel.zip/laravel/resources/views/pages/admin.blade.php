@extends('app')


@section('content')

{!! $feedback !!}

<div class="container-fluid">

	<div class="row">

		<div class="col-md-12">
	
			<h1 style="text-align:center;">Ninja´s bildeapp - Admin <a href='/' class='btn btn-info btn-xs'>Back to home page</a></h1> 
		
		</div>
	
	</div>

	<div class="row">

		<div class="col-md-6">
	
			<h3>NOT approved images</h3>
		
		</div>	
	
	</div>	

	<div class="row">

		{!! $images !!}

	</div>

</div>

@stop