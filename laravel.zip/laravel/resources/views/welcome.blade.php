<!DOCTYPE HTML>
<head>
	<title>Ninja´s bildeapp</title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
	<script src="<?php echo asset('js/jquery-1.11.1.min.js'); ?>"></script>
	
	<link rel="stylesheet" type="text/css" href="<?php echo asset('css/main.css'); ?>">

</head>

<body>
	
	<?php
	
		session_start();
		
		//user logs out
		if(isset($_GET["logout"])){
		
			$_SESSION["user_id"] = 0;
			$_SESSION["user_name"] = "";
			
		}
		
		//user uploads image
		if(isset($_GET["status"])){
			
			//image upload success
			if($_GET["status"] == 'uploaded'){
				echo "<div class='container-fluid' style='margin-top: 15px;'>";
					echo "<div class='row'>";
						echo "<div class='col-md-12'>";
							echo "<div class='alert alert-success' role='alert'>Your image was uploaded and is waiting for approval. </div>";
						echo "</div>";
					echo "</div>";	
				echo "</div>";	
			
			}
			
			//image upload error
			if($_GET["status"] == 'error'){
				echo "<div class='container-fluid' style='margin-top: 15px;'>";
					echo "<div class='row'>";
						echo "<div class='col-md-12'>";
							echo "<div class='alert alert-danger' role='alert'>Oooops, something went wrong... </div>";
						echo "</div>";
					echo "</div>";	
				echo "</div>";	
			
			}
			
			//image upload has noe file
			if($_GET["status"] == 'nofile'){
				echo "<div class='container-fluid' style='margin-top: 15px;'>";
					echo "<div class='row'>";
						echo "<div class='col-md-12'>";
							echo "<div class='alert alert-warning' role='alert'>Please choose a file.</div>";
						echo "</div>";
					echo "</div>";	
				echo "</div>";	
			
			}
		
		}
		

		//user registrers
		if(isset($_GET["registrer"])){
			
			//checks if user already exists in db
			$user = DB::table('users')->where('email', $_GET["input_email"])->get();
			
			if(empty($user)){
				
				//inserts ned user
				$user_id = DB::table('users')->insertGetId(
					['name' => $_GET["input_name"],'instagram_username' => $_GET["input_instagram"], 'email' => $_GET["input_email"], 'password' => $_GET["input_password"],]
				);
				
				//saves information in session
				$_SESSION["user_id"] = $user_id;
				$_SESSION["user_name"] = $_GET["input_name"];
				$_SESSION["user_instagram"] = $_GET["input_instagram"];
				
			}else{
				echo "<div class='container-fluid' style='margin-top: 15px;'>";
					echo "<div class='row'>";
						echo "<div class='col-md-12'>";
							echo "<div class='alert alert-danger' role='alert'>This user already exists, use login form.</div>";
						echo "</div>";
					echo "</div>";	
				echo "</div>";		

			}

		}
		
		//user logs in
		if(isset($_GET["login"])){
			
			//checks if user has registrered
			$user = DB::table('users')->where('email', $_GET["input_email"])->where('password', $_GET["input_password"])->get();
			
			if(!empty($user)){
			
				//save information to session
				$_SESSION["user_id"] = $user[0]->user_id;
				$_SESSION["user_name"] = $user[0]->name;
				$_SESSION["user_instagram"] = $user[0]->instagram_username;
				
			}else{
			
				echo "<div class='container-fluid' style='margin-top: 15px;'>";
					echo "<div class='row'>";
						echo "<div class='col-md-12'>";
							echo "<div class='alert alert-danger' role='alert'>No user with this email. Please registrer!</div>";
						echo "</div>";
					echo "</div>";	
				echo "</div>";	
				
			}	
			
		}
		
		
		//user not logged in
		if($_SESSION["user_id"] == false){
			
			//saves blank information in session
			$_SESSION["user_id"] = 0;
			$_SESSION["user_name"] = "";
			$_SESSION["user_instagram"] = "";
			
		}

	?>

			<div class="container-fluid">
			
				<div class="row">
					<div class="col-md-12">
						<h1 style="text-align:center;">Ninja´s bildeapp</h1>
					</div>
				</div>
				
				<div class="clearfix"></div>
			
				<?php if($_SESSION["user_id"] == 0){ ?>	
					
					<div class="row">
						<div class="col-md-4 col-md-offset-2">
						
							<h3>Registrering</h3>
						
							<form action="" method="get" name="registrering" value="registrering" class="box">
							
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-user"></div></span>
										<input type="text" id="input_name" name="input_name" value="" placeholder="Name" class="form-control" />
									</div>
								</p>
								
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-camera"></div></span>
										<input type="text" id="input_instagram" name="input_instagram" value="" placeholder="Instagram username" class="form-control" />
									</div>
								</p>	
								
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-envelope"></div></span>
										<input type="text" id="input_email" name="input_email" value="" placeholder="Email" class="form-control" />
									</div>
								</p>	
								
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-pencil"></div></span>
										<input type="password" id="input_password" name="input_password" placeholder="Password" value="" class="form-control" />
									</div>
								<p>	
			
								<p>
									<div class="btn-group">
										<input  class="btn btn-default btn-sm dropdown-toggle" type="submit" id="registrer" name="registrer" value="Registrer" />
									</div>
								</p>
								
							</form>		
							
						</div>
			
						<div class="col-md-4">
							
							<h3>Log in</h3>
								
							<form action="" method="get" name="registrering" value="registrering" class="box">
							
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-envelope"></div></span>
										<input type="text" id="input_email" name="input_email" value="" placeholder="Email" class="form-control" />
									</div>
								</p>	
			
								<p>
									<div class="input-group">
										<span class="input-group-addon" id="basic-addon1"><div class="glyphicon glyphicon-pencil"></div></span>
										<input type="password" id="input_password" name="input_password" placeholder="Password" value="" class="form-control" />
									</div>
								</p>	
								
								<p>
									<div class="btn-group">
										<input  class="btn btn-default btn-sm dropdown-toggle" type="submit" id="login" name="login" value="Login" />
									</div>
								</p>
								
							</form>
							
						</div>
						
					</div>
					
				<?php }else{ ?>
	
				<h3>Images uploaded by: <?php echo $_SESSION["user_name"]; ?> <a href='/?logout=true' class='btn btn-info btn-xs'>Logout</a></h3>
					<?php
						$images = DB::table('images')->where('approved', 1)->where('deleted', 0)->where('user_id', $_SESSION["user_id"] )->get();
				
						foreach ($images as $image) {
							echo "<div class='col-lg-1 col-md-2 col-xs-3 thumb'><p><img src='".asset('uploads/'.$image->path)."' class='imagebox' alt='Default' height='100' width='100'></p></div>";
						}
					?>

				<?php } ?>		
				
			</div>	

	<hr />
	
	
	<?php if($_SESSION["user_id"] > 0){ ?>
	
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
				
					<h3>Fileupload</h3>
					
					<form action="{{ URL::to('upload') }}" method="post" enctype="multipart/form-data" class="box">

				      <input type="file" name="file" id="file" placeholder="Select image to upload" style="float:left;">
				      <input type="submit" class="btn btn-default" value="Upload" name="submit" style="float:left;">
				      
				      <input type="hidden" value="<?php echo $_SESSION["user_id"]; ?>" name="userid" id="userid">
				      <input type="hidden" value="{{ csrf_token() }}" name="_token">
				      
				      <div class="clearfix"></div>

					</form>
					
				</div>
				
				<div class="col-md-8">
				
					<h3>Instagram - <small>Choose image to upload</small></h3>
					
					<div class="container-fluid">
					
						<div class="row">

                			<?php
								if($_SESSION["user_instagram"] != ""){
								
									//1 - Settings (please update to math your own)
									$username= $_SESSION["user_instagram"]; //Provide your instagram username
									$access_token='627797431.ea105d0.922dda17c2504cf59449836a7e397034'; //Provide your instagram access token
									$count='24'; //How many shots do you want?

									//2 - Include the php class
									//included in route.php

    								//3 - Instanciate
    								if(!empty($username) && $username!='yourusername' && !empty($access_token) && $access_token!='youraccesstoken'){
    									$isg = new instagramPhp($username,$access_token); //instanciates the class with the parameters
    									$shots = $isg->getUserMedia(array('count'=>$count)); //Get the shots from instagram
    								} 
                			
                					//4 - Display Instagram
               		 				if(!empty($shots)){ echo $isg->simpleDisplay($shots); }
               		 				
               		 			}else{
               		 			
               		 				echo "<div class='col-md-2'><h4>Missing Instagram username.</h4></div>";
               		 				
               		 			}	
               		 			
                			?>
                			
                			<div class="clearfix"></div>
                			
                		</div>	
                		
					</div>
					
				</div>
				
			</div>
			
		</div>	
		
		<hr />
	
	<? } ?>		
	
	
		<div class="container-fluid">
		
			<div class="row">
			
				<h2 style="text-align:center;">All images</h2>
				
				<?php
				
					$images = DB::table('images')->where('approved', 1)->where('deleted', 0)->get();
		
					foreach ($images as $image) {
					    echo "<div class='col-lg-2 col-md-3 col-xs-4 thumb'><p><img src='".asset('uploads/'.$image->path)."' class='imagebox' alt='Default' height='200' width='200'></p></div>";
					}
				?>
				
			</div>
			
		</div>

	</body>
	
</html>