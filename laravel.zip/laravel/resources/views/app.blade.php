<!DOCTYPE HTML>
	<head>
		<title>Ninja´s bildeapp</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	
		<!-- Optional theme -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	
		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
		<script src="<?php echo asset('js/jquery-1.11.1.min.js'); ?>"></script>
	
		<link rel="stylesheet" type="text/css" href="<?php echo asset('css/main.css'); ?>">

	</head>

	<body>

		@yield('content')

	</body>
	
</html>