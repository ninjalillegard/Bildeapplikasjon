<?php

namespace App\Http\Controllers;

use DB;

class UploadInstagramController extends Controller{

	public function upload(){
		
		if(isset($_GET["thumb"])){
	
			$userid = $_GET['userid'];
			$file = file_get_contents($_GET["thumb"]);

			$imageUrlArray = explode('/',$_GET["thumb"]);
			$imageName = $imageUrlArray[count($imageUrlArray)-1];
			$filename = time()."_".$imageName;
		
			$save = file_put_contents('uploads/'.$filename, $file);
			
			$insert = DB::table('images')->insert(
				['path' => $filename, 'user_id' => $userid, 'approved' => 0, 'deleted' => 0]
			);
			
			if($insert == true){
			
				header("Location: /?status=uploaded");
				exit;
				
			}else{
			
				header("Location: /?status=error");
				exit;
				
			}

		}

	}

}
