<?php

namespace App\Http\Controllers;

use DB;

class UploadInstagramController extends Controller{

	

}
