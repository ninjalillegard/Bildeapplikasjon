<?php

namespace App\Http\Controllers;

use \Input as Input;
use DB;

class UploadController extends Controller{


	public function upload(){
		
		if(Input::hasFile('file')){
			
			$userid = 0;
			$userid = $_POST['userid'];
			
			$file = Input::file('file');
			$filename = time()."_".$file->getClientOriginalName();
			$file->move('uploads',$filename);
			
			$insert = DB::table('images')->insert(
				['path' => $filename, 'user_id' => $userid, 'approved' => 0, 'deleted' => 0]
			);
			
			if($insert == true){
			
				header("Location: /?status=uploaded");
				exit;
				
			}else{
			
				header("Location: /?status=error");
				exit;
				
			}
			
		}else{
		
			header("Location: /?status=nofile");
			exit;
			
		}
		
	}

}
