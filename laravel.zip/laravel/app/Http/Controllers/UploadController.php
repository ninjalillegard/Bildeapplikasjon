<?php

namespace App\Http\Controllers;

use \Input as Input;
use DB;

class UploadController extends Controller{

	/**
		Uploads image from upload form
	*/
	public function upload(){
		
		if(Input::hasFile('file')){
			
			$userid = 0;
			$userid = $_POST['userid'];
			
			$file = Input::file('file');
			$filename = time()."_".$file->getClientOriginalName();
			$file->move('uploads',$filename);
			
			$insert = $this->insertImage($filename,$userid);
			
			if($insert == true){
			
				header("Location: /?status=uploaded");
				exit;
				
			}else{
			
				header("Location: /?status=error");
				exit;
				
			}
			
		}else{
		
			header("Location: /?status=nofile");
			exit;
			
		}
		
	}
	
	/**
		Uploads image from instagram based on url
	*/
	public function instagramupload(){
		
		if(isset($_GET["thumb"])){
	
			$userid = $_GET['userid'];
			$file = file_get_contents($_GET["thumb"]);

			$imageUrlArray = explode('/',$_GET["thumb"]);
			$imageName = $imageUrlArray[count($imageUrlArray)-1];
			$filename = time()."_".$imageName;
		
			$save = file_put_contents('uploads/'.$filename, $file);
			
			$insert = $this->insertImage($filename,$userid);
			
			if($insert == true){
			
				header("Location: /?status=uploaded");
				exit;
				
			}else{
			
				header("Location: /?status=error");
				exit;
				
			}

		}

	}
	
	/**
		Inserts a new row in DB table images
	*/
	private function insertImage($filename,$userid){
	
		$insert = DB::table('images')->insert(
			['path' => $filename, 'user_id' => $userid, 'approved' => 0, 'deleted' => 0]
		);
		
		return $insert;
	
	}

}
