<?php

namespace App\Http\Controllers;

use DB;

class PagesController extends Controller{

	/*
     * Attributes
     */
	private $access_token ='627797431.ea105d0.922dda17c2504cf59449836a7e397034';
	private $userid; //Instagram userid
	
	protected $data = []; 
	
	/**
		Show the application welcome screen to the user.
		
		@return Response
	*/
	public function welcome(){
		
		session_start();
		
		$this->data["feedback"] = "";
		$this->getImages();

		// user logs out
		if(isset($_GET["logout"])){
			
			$this->updateSession(0,"","");
			
		}
		
		// user uploads image 
		if(isset($_GET["status"])){
			
			// image upload success
			if($_GET["status"] == 'uploaded'){
		
				$this->createFeedbackHtml("success","Your image was uploaded and is waiting for approval.");
				
			}
			
			// image upload error
			if($_GET["status"] == 'error'){
			
				$this->createFeedbackHtml("danger","Oooops, something went wrong... ");
			
			}
			
			// image upload has noe file
			if($_GET["status"] == 'nofile'){
			
				$this->createFeedbackHtml("warning","Please choose a file.");

			}
		
		}
		
		// user registrers
		if(isset($_GET["registrer"])){
			
			$name = $_GET["input_name"];
			$email = $_GET["input_email"];
			$instagram = $_GET["input_instagram"];
			$password = $_GET["input_password"];
			
			// checks if user already exists in db
			$user = $this->getUser($email);
			
			if(empty($user)){
				
				// inserts new user
				$user_id = $this->registrerUser($name,$instagram,$email,$password);
				
				// saves information in session
				$this->updateSession($user_id,$name,$instagram);

				
			}else{

				$this->createFeedbackHtml("danger","This user already exists, use login form.");

			}

		}
		
		// user logs in
		if(isset($_GET["login"])){
			
			$email = $_GET["input_email"];
			$password = $_GET["input_password"];
			
			// checks if user has registrered
			$user = $this->getUser($email);

			if(!empty($user)){
			
				// checks if the password is correct
				if($user[0]->password == $password){
				
					// save information to session
					$this->updateSession($user[0]->user_id,$user[0]->name,$user[0]->instagram_username);

				}else{

					$this->createFeedbackHtml("danger","Wrong password.");
					
				}

			}else{

				$this->createFeedbackHtml("danger","No user with this email. Please registrer!");
				
			}	
			
		}
		
		// user not logged in
		if(empty($_SESSION["user_id"])){
			
			// saves blank information in session
			$this->updateSession(0,"","");
			
		}
		
		// is user logged in?
		if($_SESSION["user_id"] > 0){
		
			// get the images this user has uploaded
			$this->getUserImages();
		
			$this->updateUserdata();
		
			if($_SESSION["user_instagram"] != ""){
		
				$this->getInstagramImages();
								
			}else{
		
				$this->data["instagramimages"] = "<div class='col-md-2'><h4>Missing Instagram username.</h4></div>";
			
			}
		
		}
		
    	return view('pages.welcome', $this->data);
		
	}
	
	/**
		Show the application admin screen to the user.
	*/
	public function admin(){
		
		$this->data["feedback"] = "";

		if(isset($_GET["image_id"])){
		
			$image_id = $_GET["image_id"];
						
			if($_GET["action"] == "approve"){

				$this->updateImages(1,0);
				
				$this->createFeedbackHtml("success","Image id ".$image_id." was successfully approved");
			}
			
			if($_GET["action"] == "delete"){
			
				$this->updateImages(0,1);
				
				$this->createFeedbackHtml("danger","Image id ".$image_id." was successfully deleted");
			}
						
		}

		$this->data["images"] = $this->getAdminImages();
		
    	return view('pages.admin',$this->data);
		
	}
	
	
	/**
		Function to update information stored in session
	*/
	private function updateSession($user_id,$user_name,$user_instagram){
	
		$_SESSION["user_id"] = $user_id;
		$_SESSION["user_name"] = $user_name;
		$_SESSION["user_instagram"] = $user_instagram;
		
		$this->updateUserdata();
	}
	
	/**
		Function to update information stored in $data
	*/
	private function updateUserdata(){
	
		$this->data["user_id"] = $_SESSION["user_id"];
		$this->data["user_name"] = $_SESSION["user_name"];
		$this->data["user_instagram"] = $_SESSION["user_instagram"];
	}
	
	/**
		Function to build an html feedback.	
	*/
	private function createFeedbackHtml($type,$message){
		
		$string = "<div class='container-fluid' style='margin-top: 15px;'>";
			$string .= "<div class='row'>";
				$string .= "<div class='col-md-12'>";
					$string .= "<div class='alert alert-".$type."' role='alert'>".$message."</div>";
				$string .= "</div>";
			$string .= "</div>";	
		$string .= "</div>";
				
		$this->data["feedback"] = $string;
	
	}
	
	
	/**
		Function to get user information from DB table users based on email.
	*/
	private function getUser($email){
	
		$user = DB::table('users')->where('email', $email)->get();
		
		return $user;
	}
	
	
	/**
		Function to insert a new row in DB tabel users.
	*/
	private function registrerUser($name,$instagram,$email,$password){
	
		$user_id = DB::table('users')->insertGetId(
			['name' => $name,'instagram_username' => $instagram, 'email' => $email, 'password' => $password]
		);
		
		return $user_id;
	}
	
	/**
		Function to get from the DB the images the user has uploaded
	*/
	private function getUserImages(){
		
		$string = "";
		
		$images = DB::table('images')->where('approved', 1)->where('deleted', 0)->where('user_id', $_SESSION["user_id"] )->get();

		foreach ($images as $image) {
		
			$string .= "<div class='col-lg-1 col-md-2 col-xs-3 thumb'>";
				$string .= "<p>";
					$string .= "<img src='".asset('uploads/'.$image->path)."' class='imagebox' alt='Default' height='100' width='100'>";
				$string .= "</p>";
			$string .= "</div>";
			
		}
		
		$this->data["userimages"] = $string;
			
	}
	
	/**
		Function to get the images from instagram based on instagram username
	*/
	private function getInstagramImages(){
		
		$string = "";

		$count="24"; //How many shots do you want?
	
	
		if(!empty($this->data["user_instagram"]) && !empty($this->access_token)){

			$shots = $this->getUserMedia(array('count'=>$count)); //Get the shots from instagram
		} 

		if(!empty($shots)){ 
			$string .= $this->simpleDisplay($shots); 
		}
		
		$this->data["instagramimages"] = $string;	
	
	}
	
	/**
		Function to get all images where approved = true and deleted = false from DB
	*/
	private function getImages(){
	
		$string = "";
						
		$images = DB::table('images')->where('approved', 1)->where('deleted', 0)->get();

		foreach ($images as $image) {
			$string .= "<div class='col-lg-2 col-md-3 col-xs-4 thumb'>";
				$string .= "<p>";
					$string .= "<img src='".asset('uploads/'.$image->path)."' class='imagebox' alt='Default' height='200' width='200'>";
				$string .= "</p>";
			$string .= "</div>";
		}
		
		$this->data["allimages"] = $string;
	
	}
	
	/**
		Function to get images from DB
	*/
	private function getAdminImages(){
	
		$images = DB::table('images')->where('approved', 0)->where('deleted', 0)->join('users', function ($join) {
        	$join->on('images.user_id', '=', 'users.user_id');})->get();
        
        return $this->buildImagesHtml($images);
	
	}
	
	/**
		Function to build HTML for images waiting for approval in admin
	*/
	private function buildImagesHtml($images){
		
		$string = "";
		
		if(empty($images) ){
			
			$string .= "<div class='col-md-12'>";
				$string .= "<div class='alert alert-warning' role='alert'>No new images to approve...</div>";
			$string .= "</div>";
		
		}else{
	
			foreach ($images as $image) {

				$string .= "<div class='col-lg-3 col-md-4 col-xs-6 thumb' style='margin-top: 10px;'>";
					$string .= "<div class='imagebox'>";
						$string .= "<img src='".asset('uploads/'.$image->path)."' alt='Default' height='200' width='200'>";
						$string .= "<h5>From: ".$image->name."</h5>";
					
						$string .= "<p style='margin-top: 10px;'>";
							$string .= "<a href='/admin?image_id=".$image->image_id."&action=approve' class='btn btn-success btn-md'><span class='glyphicon glyphicon-ok'></span> Approve</a>";
							$string .= "<a href='/admin?image_id=".$image->image_id."&action=delete' class='btn btn-danger btn-md'><span class='glyphicon glyphicon-remove'></span> Delete</a>";
						$string .= "</p>";
					$string .= "</div>";		
				$string .= "</div>";

			}
		
		}	
		
		return $string;
	
	}
	
	/**
		Function to update a row in DB image table
	*/
	private function updateImages($approve,$delete){
	
		DB::table('images')
			->where('image_id', $_GET["image_id"])
			->update(['deleted' => $delete, 'approved' => $approve]);
	
	}
	
	
/*******************************************************/
/****************** instagramPhp ***********************/
/*******************************************************/

    /*
     * The api works mostly with user ids, but it's easier for users to use their username.
     * This function gets the userid corresponding to the username
     */
    public function getUserIDFromUserName(){
    
        if(strlen($this->data["user_instagram"])>0 && strlen($this->access_token)>0){
        
            //Search for the username
            $useridquery = $this->queryInstagram('https://api.instagram.com/v1/users/search?q='.$this->data["user_instagram"].'&access_token='.$this->access_token);
            
            if(!empty($useridquery) && $useridquery->meta->code=='200' && $useridquery->data[0]->id>0){
                //Found
                $this->userid=$useridquery->data[0]->id;
            } else {
                //Not found
                $this->error('getUserIDFromUserName');
            }
            
        } else {
        
            $this->error('empty username or access token');
            
        }
    }

    /*
     * Get the most recent media published by a user.
     * you can use the $args array to pass the attributes that are used by the GET/users/user-id/media/recent method
     */
    public function getUserMedia($args=array()){
    
        if($this->userid<=0){
        
            //If no user id, get user id
            $this->getUserIDFromUserName();
            
        }
        
        if($this->userid>0 && strlen($this->access_token)>0){
        
            $qs='';
            if(!empty($args)){ $qs = '&'.http_build_query($args); } //Adds query string if any args are specified
            $shots = $this->queryInstagram('https://api.instagram.com/v1/users/'.(int)$this->userid.'/media/recent?access_token='.$this->access_token.$qs); //Get shots
            if($shots->meta->code=='200'){
                return $shots;
            } else {
                $this->error('getUserMedia');
            }
            
        } else {
        
            $this->error('empty username or access token');
        }
        
    }

    /*
     * Method that simply displays the shots in a ul.
     * Used for simplicity and demo purposes
     * You should probably move the markup out of this class to use it directly in your page markup
     */
    public function simpleDisplay($shots){
    
        $simpleDisplay = '';
        
        if(!empty($shots->data)){
            
                foreach($shots->data as $istg){
                
                    //The image
                    $istg_thumbnail = $istg->{'images'}->{'thumbnail'}->{'url'}; //Thumbnail
                    //If you want to display another size, you can use 'low_resolution', or 'standard_resolution' in place of 'thumbnail'

                    //The link
                    $istg_link = $istg->{'link'}; //Link to the picture's instagram page, to link to the picture image only, use $istg->{'images'}->{'standard_resolution'}->{'url'}

                    //The caption
                    $istg_caption = $istg->{'caption'}->{'text'};

                    //The markup
                    $simpleDisplay.='<div class="col-md-2 col-xs-3 thumb" style="margin-top: 5px;">';
                    	$simpleDisplay.='<a href="/instagramupload?userid='.$_SESSION["user_id"].'&thumb='.$istg_thumbnail.'">';
                    		$simpleDisplay.='<img src="'.$istg_thumbnail.'" alt="'.$istg_caption.'" title="'.$istg_caption.'"  width="100" height="100" class="imagebox" />';
                    		$simpleDisplay.= '</a>';
                    $simpleDisplay.='</div>';
                }
            
        } else {
        
            $this->error('simpleDisplay');
        }
        
        return $simpleDisplay;
        
    }

    /*
     * Common mechanism to query the instagram api
     */
    public function queryInstagram($url){
    
        //prepare caching
        $cachefolder = __DIR__.'/';
        $cachekey = md5($url);
        $cachefile = $cachefolder.$cachekey.'_'.date('i').'.txt'; //cached for one minute

        //If not cached, -> instagram request
        if(!file_exists($cachefile)){
        
            //Request
            $request='error';
            if(!extension_loaded('openssl')){ $request = 'This class requires the php extension open_ssl to work as the instagram api works with httpS.'; }
            else { $request = file_get_contents($url); }

            //remove old caches
            $oldcaches = glob($cachefolder.$cachekey."*.txt");
            if(!empty($oldcaches)){foreach($oldcaches as $todel){
              unlink($todel);
            }}
            
            //Cache result
            $rh = fopen($cachefile,'w+');
            fwrite($rh,$request);
            fclose($rh);
            
        }
        
        //Execute and return query
        $query = json_decode(file_get_contents($cachefile));
        
        return $query;
        
    }

    /*
     * Error
     */
    public function error($src=''){
    
        echo '/!\ error '.$src.'. ';
        
    }


}
